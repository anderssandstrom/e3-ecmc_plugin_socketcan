#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xa2294dd7, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x66681287, __VMLINUX_SYMBOL_STR(usb_deregister) },
	{ 0x4b8cd9d4, __VMLINUX_SYMBOL_STR(usb_register_driver) },
	{ 0xa2a93cc1, __VMLINUX_SYMBOL_STR(__dynamic_dev_dbg) },
	{ 0x76cd0960, __VMLINUX_SYMBOL_STR(register_candev) },
	{ 0xc38ec25f, __VMLINUX_SYMBOL_STR(alloc_candev) },
	{ 0x660501f5, __VMLINUX_SYMBOL_STR(__rt_spin_lock_init) },
	{ 0xdd050861, __VMLINUX_SYMBOL_STR(__rt_mutex_init) },
	{ 0xb9de9b84, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x1eb4a4ad, __VMLINUX_SYMBOL_STR(devm_kmalloc) },
	{ 0xa568d439, __VMLINUX_SYMBOL_STR(wait_for_completion_timeout) },
	{ 0x4c7dff4d, __VMLINUX_SYMBOL_STR(__init_swait_queue_head) },
	{ 0xeb85dec7, __VMLINUX_SYMBOL_STR(close_candev) },
	{ 0xecda1118, __VMLINUX_SYMBOL_STR(usb_alloc_coherent) },
	{ 0xda74c946, __VMLINUX_SYMBOL_STR(open_candev) },
	{ 0xaccb8e7d, __VMLINUX_SYMBOL_STR(usb_bulk_msg) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0x3bd1b1f6, __VMLINUX_SYMBOL_STR(msecs_to_jiffies) },
	{ 0xcf3f097e, __VMLINUX_SYMBOL_STR(completion_done) },
	{ 0x856faaa9, __VMLINUX_SYMBOL_STR(netif_tx_wake_queue) },
	{ 0x7d904b3f, __VMLINUX_SYMBOL_STR(can_get_echo_skb) },
	{ 0x34fe9495, __VMLINUX_SYMBOL_STR(alloc_can_skb) },
	{ 0x160753c, __VMLINUX_SYMBOL_STR(dev_warn) },
	{ 0x7f9a9170, __VMLINUX_SYMBOL_STR(complete) },
	{ 0x8e2d3fc9, __VMLINUX_SYMBOL_STR(_dev_info) },
	{ 0xe93d2e93, __VMLINUX_SYMBOL_STR(netif_device_detach) },
	{ 0xcec4430d, __VMLINUX_SYMBOL_STR(can_free_echo_skb) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x3b82a360, __VMLINUX_SYMBOL_STR(consume_skb) },
	{ 0xf7ab7910, __VMLINUX_SYMBOL_STR(can_put_echo_skb) },
	{ 0x69acdf38, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xaaa4f7c1, __VMLINUX_SYMBOL_STR(kfree_skb) },
	{ 0x3b33cb37, __VMLINUX_SYMBOL_STR(__dynamic_netdev_dbg) },
	{ 0xf0fdf6cb, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x51572588, __VMLINUX_SYMBOL_STR(netif_carrier_on) },
	{ 0x5bbbaa5, __VMLINUX_SYMBOL_STR(netif_rx) },
	{ 0xb0d20497, __VMLINUX_SYMBOL_STR(netif_carrier_off) },
	{ 0xb77b74f1, __VMLINUX_SYMBOL_STR(alloc_can_err_skb) },
	{ 0xb61de5b, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x16305289, __VMLINUX_SYMBOL_STR(warn_slowpath_null) },
	{ 0x87de562a, __VMLINUX_SYMBOL_STR(netdev_info) },
	{ 0xfc304312, __VMLINUX_SYMBOL_STR(usb_unanchor_urb) },
	{ 0xed39e4f3, __VMLINUX_SYMBOL_STR(netdev_err) },
	{ 0xa2e701bf, __VMLINUX_SYMBOL_STR(usb_free_urb) },
	{ 0x18b8900, __VMLINUX_SYMBOL_STR(usb_submit_urb) },
	{ 0x33f4c617, __VMLINUX_SYMBOL_STR(usb_anchor_urb) },
	{ 0x877bb560, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0x4e74ee2e, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x29b3b24d, __VMLINUX_SYMBOL_STR(usb_alloc_urb) },
	{ 0x74bb70bf, __VMLINUX_SYMBOL_STR(netdev_warn) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x91f55277, __VMLINUX_SYMBOL_STR(dev_set_drvdata) },
	{ 0xdfcaf1a5, __VMLINUX_SYMBOL_STR(dev_get_drvdata) },
	{ 0xd80f687b, __VMLINUX_SYMBOL_STR(free_candev) },
	{ 0x21cf698d, __VMLINUX_SYMBOL_STR(usb_free_coherent) },
	{ 0x2971bbdb, __VMLINUX_SYMBOL_STR(usb_kill_anchored_urbs) },
	{ 0xc3133190, __VMLINUX_SYMBOL_STR(unregister_netdev) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=can-dev";

MODULE_ALIAS("usb:v0BFDp000Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp000Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp000Cd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp000Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp000Fd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0010d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0011d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0012d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0013d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0016d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0017d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0018d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0019d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp001Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp001Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp001Cd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp001Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0022d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0023d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0027d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0120d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BFDp0121d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "7AA32581024E3C4987C0341");
MODULE_INFO(rhelversion, "7.7");
#ifdef RETPOLINE
	MODULE_INFO(retpoline, "Y");
#endif
#ifdef CONFIG_MPROFILE_KERNEL
	MODULE_INFO(mprofile, "Y");
#endif
